# File tree in py.zip
```
.
├── Readme.md
├── module
│   ├── __init__.py
│   ├── module
│   │   └── part3.py
│   ├── part1.py
│   └── part2.py
└── single.py

2 directories, 6 files
```