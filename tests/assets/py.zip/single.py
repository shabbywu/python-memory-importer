def flag():
    return "single"
