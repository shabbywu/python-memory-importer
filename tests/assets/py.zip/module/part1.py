def flag():
    return "part1"
