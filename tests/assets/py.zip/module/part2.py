def flag():
    return "part2"
