def flag():
    return "part3"
